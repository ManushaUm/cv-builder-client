from typing import Literal

from pydantic.json_schema import SkipJsonSchema

available_font_families = sorted(
    [
        # Typst built-ins
        "Libertinus Serif",
        "New Computer Modern",
        "DejaVu Sans Mono",
        # RenderCV bundled
        "Mukta",
        "Open Sans",
        "Gentium Book Plus",
        "Noto Sans",
        "Lato",
        "Source Sans 3",
        "EB Garamond",
        "Open Sauce Sans",
        "Fontin",
        "Roboto",
        "Ubuntu",
        "Poppins",
        "Raleway",
        "XCharter",
    ]
)


type FontFamily = SkipJsonSchema[str] | Literal[*tuple(available_font_families)]  # ty: ignore[invalid-type-form]
